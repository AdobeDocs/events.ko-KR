# CQGEM Screens Sample project

This is a sample project for the [Screens Gems Session](https://docs.adobe.com/ddc/en/gems/Introduction-to-AEM-Screens.html).

## How to build

To build all the modules run in the project root directory the following command with Maven 3:

    mvn clean install

If you have a running AEM instance you can build and package the whole project and deploy into AEM with  

    mvn clean install -PautoInstallPackage

Or to deploy it to a publish instance, run

    mvn clean install -PautoInstallPackagePublish

Or to deploy only the bundle to the author, run

    mvn clean install -PautoInstallBundle
